# EasyBot (Fabric 1.21.11)
Zrodla odzyskane z jara, przemapowane z intermediary na Yarn 1.21.11. Funkcje dodane: Auto login, Auto AFK, motywy GUI.

Build: wrzuc repo na GitHub -> zakladka Actions -> artefakt "Artifacts" (jar w build/libs).
Jesli build sie wywali, bledy kompilacji sa w logu kroku "build". PORTING_NOTES_raw.txt - lista zmian API 1.21.4 -> 1.21.11.
